package pack01;

public class Accout {
	
	static void method(){
		String ownerName="";
		String accountNo="";
		int balance=0;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
