package ex2������18110;

import java.util.Scanner;

public class ex5 {

	public static void main(String[] args) {
		
		int k1=14;
		int k2=18;
		int k3=27;
		int t1=0;
		int t2=0;
		int t3=0;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("��й�ȣ�� �Է��ϼ��� : ");
		int password = sc.nextInt();
		
		loop1: for(int a=1; a<4; a++) {    //k1������Ʈ
			if (a==1) t1=5;
			if (a==2) t1=2;
			if (a==3) t1=9;
			for(int b=1; b<4; b++) {      //k2������Ʈ
				if (b==1) t2=5;
				if (b==2) t2=2;
				if (b==3) t2=9;
				for(int c=1; c<4; c++) {     //k3������Ʈ
					if (c==1) t3=5;
					if (c==2) t3=2;
					if (c==3) t3=9;
					
					
					
					
					
					
					if ((k1-t1)*10000+(k2-t2)*100+(k3-t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14-"+t1+")(18-"+t2+")(27-"+t3+")");
						break loop1;
					}
					if ((k1-t1)*10000+(k2-t2)*100+(k3+t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14-"+t1+")(18-"+t2+")(27+"+t3+")");
						break loop1;
					}
					if ((k1-t1)*10000+(k2-t2)*100+(k3*t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14-"+t1+")(18-"+t2+")(27*"+t3+")");
						break loop1;
					}
					if ((k1-t1)*10000+(k2+t2)*100+(k3-t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14-"+t1+")(18+"+t2+")(27-"+t3+")");
						break loop1;
					}
					if ((k1-t1)*10000+(k2+t2)*100+(k3+t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14-"+t1+")(18+"+t2+")(27+"+t3+")");
						break loop1;
					}
					if ((k1-t1)*10000+(k2+t2)*100+(k3*t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14-"+t1+")(18+"+t2+")(27*"+t3+")");
						break loop1;
					}
					if ((k1-t1)*10000+(k2*t2)*100+(k3-t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14-"+t1+")(18*"+t2+")(27-"+t3+")");
						break loop1;
					}
					if ((k1-t1)*10000+(k2*t2)*100+(k3+t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14-"+t1+")(18*"+t2+")(27+"+t3+")");
						break loop1;
					}					
					if ((k1-t1)*10000+(k2*t2)*100+(k3*t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14-"+t1+")(18*"+t2+")(27*"+t3+")");
						break loop1;
					}
					
					
					
					
					
					
					if ((k1+t1)*10000+(k2-t2)*100+(k3-t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14+"+t1+")(18-"+t2+")(27-"+t3+")");
						break loop1;
					}
					if ((k1+t1)*10000+(k2-t2)*100+(k3+t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14+"+t1+")(18-"+t2+")(27+"+t3+")");
						break loop1;
					}
					if ((k1+t1)*10000+(k2-t2)*100+(k3*t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14+"+t1+")(18-"+t2+")(27*"+t3+")");
						break loop1;
					}
					if ((k1+t1)*10000+(k2+t2)*100+(k3-t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14+"+t1+")(18+"+t2+")(27-"+t3+")");
						break loop1;
					}
					if ((k1+t1)*10000+(k2+t2)*100+(k3+t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14+"+t1+")(18+"+t2+")(27+"+t3+")");
						break loop1;
					}
					if ((k1+t1)*10000+(k2+t2)*100+(k3*t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14+"+t1+")(18+"+t2+")(27*"+t3+")");
						break loop1;
					}
					if ((k1+t1)*10000+(k2*t2)*100+(k3-t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14+"+t1+")(18*"+t2+")(27-"+t3+")");
						break loop1;
					}
					if ((k1+t1)*10000+(k2*t2)*100+(k3+t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14+"+t1+")(18*"+t2+")(27+"+t3+")");
						break loop1;
					}					
					if ((k1+t1)*10000+(k2*t2)*100+(k3*t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14+"+t1+")(18*"+t2+")(27*"+t3+")");
						break loop1;
					}
					
					
					
					
					
					
					if ((k1*t1)*10000+(k2-t2)*100+(k3-t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14*"+t1+")(18-"+t2+")(27-"+t3+")");
						break loop1;
					}
					if ((k1*t1)*10000+(k2-t2)*100+(k3+t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14*"+t1+")(18-"+t2+")(27+"+t3+")");
						break loop1;
					}
					if ((k1*t1)*10000+(k2-t2)*100+(k3*t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14*"+t1+")(18-"+t2+")(27*"+t3+")");
						break loop1;
					}
					if ((k1*t1)*10000+(k2+t2)*100+(k3-t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14*"+t1+")(18+"+t2+")(27-"+t3+")");
						break loop1;
					}
					if ((k1*t1)*10000+(k2+t2)*100+(k3+t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14*"+t1+")(18+"+t2+")(27+"+t3+")");
						break loop1;
					}
					if ((k1*t1)*10000+(k2+t2)*100+(k3*t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14*"+t1+")(18+"+t2+")(27*"+t3+")");
						break loop1;
					}
					if ((k1*t1)*10000+(k2*t2)*100+(k3-t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14*"+t1+")(18*"+t2+")(27-"+t3+")");
						break loop1;
					}
					if ((k1*t1)*10000+(k2*t2)*100+(k3+t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14*"+t1+")(18*"+t2+")(27+"+t3+")");
						break loop1;
					}					
					if ((k1*t1)*10000+(k2*t2)*100+(k3*t3)==password) {
						System.out.println("��й�ȣ : "+password+"\n���ս� : (14*"+t1+")(18*"+t2+")(27*"+t3+")");
						break loop1;
					}
				}
			}
		}

	}

}
