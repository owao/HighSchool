package ex2������18110;

import java.lang.Math;

public class ex1 {

	public static void main(String[] args) {
		int ball_1 = (int) ((Math.random()*30)+1);
		int ball_2 = (int) ((Math.random()*30)+1);
		int ball_3 = (int) ((Math.random()*30)+1);
		int ball_4 = (int) ((Math.random()*30)+1);
		int ball_5 = (int) ((Math.random()*30)+1);
		
		System.out.println(ball_1);
		System.out.println(ball_2);
		System.out.println(ball_3);
		System.out.println(ball_4);
		System.out.println(ball_5);

	}

}
