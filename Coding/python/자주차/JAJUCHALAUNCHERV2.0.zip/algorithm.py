from jajuchaUtil import *

def autoDrive_algorithm(original_img, canny_img, points, lines, LiDAR, prevComm, status, light):
    command = prevComm

    # write your code here..


    return command, status, light