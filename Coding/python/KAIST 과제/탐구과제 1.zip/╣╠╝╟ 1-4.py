def printbook(book):
    a=list(book.keys())
    for b in a:
        c=contact(b,book)
        c.print_c()
    
