import turtle
turtle.up()
for i in range(0,2):
    turtle.left(45)
    turtle.forward(150)
turtle.down()
while True:
    turtle.speed(0)
    turtle.left(145)
    turtle.forward(500)
