import Friend_AI
import My_AI

log=[]
c=0
d=0

while True:
    a=My_AI.say(log)
    print(a)
    log.append(a)
    b=Friend_AI.say(log)
    print(b)
    log.append(b)
