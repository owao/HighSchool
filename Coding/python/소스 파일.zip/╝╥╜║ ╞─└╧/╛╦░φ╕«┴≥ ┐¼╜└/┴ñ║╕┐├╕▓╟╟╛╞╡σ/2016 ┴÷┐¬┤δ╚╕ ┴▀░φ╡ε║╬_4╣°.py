d=0
for a in range(99999):
    b=str(a)
    for c in b:
        if c=="1":
            d=d+1

print(d)
